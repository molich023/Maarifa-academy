/* ================================================================
   FUTUREMINDS ACADEMY — SHARED JS
   Supabase client, auth helpers, utilities
   ================================================================ */

// ──────────────────────────────────────────────
// CONFIGURATION  — replace with your real values
// ──────────────────────────────────────────────
const MA_CONFIG = {
  supabaseUrl:  'https://YOUR_PROJECT_ID.supabase.co',
  supabaseKey:  'YOUR_ANON_KEY_HERE',
  siteName:     'Maarifa Academy',
  phone:        '0736-340024',
  email:        'info@maarifaacademy.co.ke',
  certPrefix:   'MAA'',
};

// ──────────────────────────────────────────────
// SUPABASE CLIENT
// ──────────────────────────────────────────────
let _sb = null;
function sb() {
  if (!_sb && window.supabase) {
    _sb = window.supabase.createClient(MA_CONFIG.supabaseUrl, MA_CONFIG.supabaseKey);
  }
  return _sb;
}

// ──────────────────────────────────────────────
// AUTH HELPERS
// ──────────────────────────────────────────────
const Auth = {
  async getUser() {
    const client = sb();
    if (!client) return JSON.parse(sessionStorage.getItem('ma_demo_user') || 'null');
    const { data } = await client.auth.getUser();
    return data?.user || null;
  },

  async getProfile(userId) {
    const client = sb();
    if (!client) return JSON.parse(sessionStorage.getItem('ma_demo_profile') || 'null');
    const { data } = await client.from('profiles').select('*').eq('id', userId).single();
    return data;
  },

  async signUp(email, password, meta) {
    const client = sb();
    if (!client) throw new Error('Supabase not configured');
    return client.auth.signUp({ email, password, options: { data: meta } });
  },

  async signIn(email, password) {
    const client = sb();
    if (!client) throw new Error('Supabase not configured');
    return client.auth.signInWithPassword({ email, password });
  },

  async signOut() {
    const client = sb();
    if (client) await client.auth.signOut();
    sessionStorage.clear();
    window.location.href = '/pages/student-portal.html';
  },

  demoLogin(name, email) {
    const user   = { id: 'demo-001', email };
    const profile = {
      id: 'demo-001', full_name: name, email, phone: '0700000000',
      county: 'Nairobi', points: 1240, streak: 7, role: 'student',
      enrolled_at: new Date().toISOString()
    };
    sessionStorage.setItem('ma_demo_user',    JSON.stringify(user));
    sessionStorage.setItem('ma_demo_profile', JSON.stringify(profile));
    return { user, profile };
  }
};

// ──────────────────────────────────────────────
// PROGRESS HELPERS
// ──────────────────────────────────────────────
const Progress = {
  key(userId, courseId) { return `ma_progress_${userId}_${courseId}`; },

  get(userId, courseId) {
    return JSON.parse(localStorage.getItem(this.key(userId, courseId)) || '{}');
  },

  markComplete(userId, courseId, moduleId) {
    const p = this.get(userId, courseId);
    if (!p.completed) p.completed = [];
    if (!p.completed.includes(moduleId)) p.completed.push(moduleId);
    p.lastModule = moduleId;
    p.updatedAt  = Date.now();
    localStorage.setItem(this.key(userId, courseId), JSON.stringify(p));
    return p;
  },

  percent(userId, courseId, total) {
    const p = this.get(userId, courseId);
    return total ? Math.round(((p.completed?.length || 0) / total) * 100) : 0;
  }
};

// ──────────────────────────────────────────────
// QUIZ HELPERS
// ──────────────────────────────────────────────
const QuizStore = {
  key(userId, quizId) { return `fm_quiz_${userId}_${quizId}`; },

  save(userId, quizId, result) {
    const existing = this.getAll(userId);
    existing[quizId] = { ...result, savedAt: Date.now() };
    localStorage.setItem(`ma_quizzes_${userId}`, JSON.stringify(existing));
  },

  getAll(userId) {
    return JSON.parse(localStorage.getItem(`ma_quizzes_${userId}`) || '{}');
  },

  get(userId, quizId) {
    return this.getAll(userId)[quizId] || null;
  }
};

// ──────────────────────────────────────────────
// CERTIFICATE HELPERS
// ──────────────────────────────────────────────
const Certificates = {
  generate(studentName, courseName, score, date) {
    const rand = Math.random().toString(36).substr(2, 6).toUpperCase();
    const courseCode = courseName.replace(/\s+/g,'').substr(0, 6).toUpperCase();
    const year = new Date(date).getFullYear();
    return `${MA_CONFIG.certPrefix}-${year}-${courseCode}-${rand}`;
  },

  store(userId, cert) {
    const all = this.getAll(userId);
    all[cert.id] = cert;
    localStorage.setItem(`ma_certs_${userId}`, JSON.stringify(all));
  },

  getAll(userId) {
    return JSON.parse(localStorage.getItem(`ma_certs_${userId}`) || '{}');
  }
};

// ──────────────────────────────────────────────
// NAVBAR SCROLL EFFECT
// ──────────────────────────────────────────────
function initNavbar() {
  const nav = document.querySelector('.navbar');
  const hb  = document.getElementById('hamburger');
  const nl  = document.getElementById('navLinks');
  const nc  = document.getElementById('navCta');

  if (!nav) return;

  const onScroll = () => {
    nav.classList.toggle('scrolled', window.scrollY > 40);
  };
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  hb?.addEventListener('click', () => {
    nl?.classList.toggle('open');
    nc?.classList.toggle('open');
  });

  document.querySelectorAll('.nav-links a').forEach(a =>
    a.addEventListener('click', () => {
      nl?.classList.remove('open');
      nc?.classList.remove('open');
    })
  );
}

// ──────────────────────────────────────────────
// COUNTER ANIMATION
// ──────────────────────────────────────────────
function animateCounters() {
  const counters = document.querySelectorAll('[data-count]');
  const io = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      const el  = entry.target;
      const end = parseFloat(el.dataset.count);
      const suffix = el.dataset.suffix || '';
      let current = 0;
      const step  = end / 60;
      const timer = setInterval(() => {
        current = Math.min(current + step, end);
        el.textContent = Number.isInteger(end) ? Math.floor(current).toLocaleString() + suffix : current.toFixed(1) + suffix;
        if (current >= end) clearInterval(timer);
      }, 20);
      io.unobserve(el);
    });
  }, { threshold: 0.5 });
  counters.forEach(el => io.observe(el));
}

// ──────────────────────────────────────────────
// SCROLL REVEAL
// ──────────────────────────────────────────────
function initReveal() {
  const io = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        io.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' });

  document.querySelectorAll('.reveal').forEach((el, i) => {
    el.style.transitionDelay = (i % 4) * 0.08 + 's';
    io.observe(el);
  });
}

// ──────────────────────────────────────────────
// COURSE TABS
// ──────────────────────────────────────────────
function initTabs() {
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const panel = btn.dataset.tab;
      btn.closest('.tabs-wrapper')?.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const section = btn.closest('section') || document;
      section.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
      section.querySelector(`#tab-${panel}`)?.classList.add('active');
    });
  });
}

// ──────────────────────────────────────────────
// TOAST NOTIFICATIONS
// ──────────────────────────────────────────────
function toast(msg, type = 'info', duration = 3500) {
  const colours = { info: 'var(--primary)', success: 'var(--success)', error: 'var(--danger)', warning: 'var(--warning)' };
  const icons   = { info: 'ℹ️', success: '✅', error: '❌', warning: '⚠️' };
  const el = document.createElement('div');
  el.style.cssText = `
    position:fixed;bottom:28px;right:28px;z-index:9999;
    background:var(--surf2);border:1px solid ${colours[type]};
    border-radius:12px;padding:14px 18px;
    display:flex;align-items:center;gap:10px;
    font-size:14px;font-family:var(--font-b);
    color:var(--text);box-shadow:var(--shadow);
    animation:slide-up 0.3s ease;max-width:340px;
  `;
  el.innerHTML = `<span>${icons[type]}</span><span>${msg}</span>`;
  document.body.appendChild(el);
  setTimeout(() => { el.style.opacity = '0'; el.style.transition = 'opacity 0.3s'; setTimeout(() => el.remove(), 300); }, duration);
}

// ──────────────────────────────────────────────
// SMOOTH SCROLL FOR HASH LINKS
// ──────────────────────────────────────────────
function initSmoothScroll() {
  document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', e => {
      const target = document.querySelector(a.getAttribute('href'));
      if (target) { e.preventDefault(); target.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
    });
  });
}

// ──────────────────────────────────────────────
// UTILS
// ──────────────────────────────────────────────
const Utils = {
  qs:  (sel, ctx = document) => ctx.querySelector(sel),
  qsa: (sel, ctx = document) => [...ctx.querySelectorAll(sel)],
  el:  (tag, cls, html = '') => { const e = document.createElement(tag); if (cls) e.className = cls; if (html) e.innerHTML = html; return e; },
  fmtDate: d => new Date(d).toLocaleDateString('en-KE', { day: 'numeric', month: 'long', year: 'numeric' }),
  initials: name => name.split(' ').map(w => w[0]).join('').toUpperCase().substr(0, 2),
  slugify: s => s.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, ''),
  clamp:  (n, min, max) => Math.min(Math.max(n, min), max),
};

// ──────────────────────────────────────────────
// COURSE DATA
// ──────────────────────────────────────────────
const COURSES = {
  'ms-word': {
    id: 'ms-word', title: 'Microsoft Word Mastery', emoji: '📝',
    category: 'computer', level: 'Beginner', duration: '12 hrs',
    modules: 8, color: 'linear-gradient(135deg,#1B5FBF,#2E86DE)',
    desc: 'From typing documents to advanced formatting, mail merge, and professional reports.',
    videos: ['https://www.youtube.com/embed/S-pFRXFpWR4','https://www.youtube.com/embed/7_sHDVa3iUM'],
    pdf: '#', ext: 'https://support.microsoft.com/en-us/word',
    modules_list: [
      {id:'mw-1', title:'Introduction to Word Interface', duration:'20 min'},
      {id:'mw-2', title:'Typing, Editing & Formatting Text', duration:'25 min'},
      {id:'mw-3', title:'Paragraphs, Alignment & Spacing', duration:'20 min'},
      {id:'mw-4', title:'Tables & Lists', duration:'25 min'},
      {id:'mw-5', title:'Headers, Footers & Page Numbers', duration:'20 min'},
      {id:'mw-6', title:'Images, Shapes & SmartArt', duration:'30 min'},
      {id:'mw-7', title:'Mail Merge & Templates', duration:'35 min'},
      {id:'mw-8', title:'Collaboration & Track Changes', duration:'25 min'},
    ],
    quiz: [
      {q:'What does "CTRL + B" do in Word?',opts:['Bold text','Create a Bullet','Add a Border','Open a new file'],ans:0},
      {q:'Which tab contains the mail merge feature?',opts:['Home','Insert','Mailings','Review'],ans:2},
      {q:'What is a "Header" in a Word document?',opts:['The first paragraph','Text at the top of every page','A title style','A watermark'],ans:1},
      {q:'How do you select ALL text in a document?',opts:['CTRL+S','CTRL+A','CTRL+F','CTRL+Z'],ans:1},
      {q:'Which format saves a document so it cannot be edited easily?',opts:['.docx','.txt','.pdf','.doc'],ans:2},
    ]
  },
  'ms-excel': {
    id: 'ms-excel', title: 'Microsoft Excel & Data', emoji: '📊',
    category: 'computer', level: 'Beginner', duration: '15 hrs',
    modules: 10, color: 'linear-gradient(135deg,#1A7431,#27AE60)',
    desc: 'Spreadsheets, formulas, pivot tables, charts. Excel is used in every business worldwide.',
    videos: ['https://www.youtube.com/embed/rwbho0CgEAI','https://www.youtube.com/embed/9NUjHBNWe9M'],
    pdf: '#', ext: 'https://support.microsoft.com/en-us/excel',
    modules_list: [
      {id:'me-1',title:'Excel Interface & Navigation',duration:'20 min'},
      {id:'me-2',title:'Entering & Formatting Data',duration:'25 min'},
      {id:'me-3',title:'Basic Formulas: SUM, AVERAGE, COUNT',duration:'30 min'},
      {id:'me-4',title:'IF, COUNTIF, SUMIF Functions',duration:'35 min'},
      {id:'me-5',title:'VLOOKUP & HLOOKUP',duration:'35 min'},
      {id:'me-6',title:'Charts & Data Visualisation',duration:'30 min'},
      {id:'me-7',title:'Pivot Tables & Pivot Charts',duration:'40 min'},
      {id:'me-8',title:'Data Validation & Protection',duration:'25 min'},
      {id:'me-9',title:'Conditional Formatting',duration:'20 min'},
      {id:'me-10',title:'Real-World Project: Budget Tracker',duration:'60 min'},
    ],
    quiz: [
      {q:'What formula adds up a range of cells?',opts:['=ADD(A1:A10)','=SUM(A1:A10)','=TOTAL(A1:A10)','=COUNT(A1:A10)'],ans:1},
      {q:'What does VLOOKUP do?',opts:['Sorts data A to Z','Looks up a value vertically in a table','Creates a vertical chart','Rotates the spreadsheet'],ans:1},
      {q:'What is a Pivot Table used for?',opts:['Drawing tables','Analysing large datasets quickly','Rotating the screen','Sorting A-Z only'],ans:1},
      {q:'Which function counts cells meeting a condition?',opts:['COUNT()','IF()','COUNTIF()','SUMIF()'],ans:2},
      {q:'Shortcut to create a new worksheet?',opts:['CTRL+N','CTRL+T','SHIFT+F11','ALT+W'],ans:2},
    ]
  },
  'ms-powerpoint': {
    id: 'ms-powerpoint', title: 'PowerPoint & Presentations', emoji: '🖥️',
    category: 'computer', level: 'Beginner', duration: '8 hrs',
    modules: 6, color: 'linear-gradient(135deg,#B03A2E,#E74C3C)',
    desc: 'Design stunning presentations that communicate ideas with clarity and professionalism.',
    videos: ['https://www.youtube.com/embed/TWY4bXTqDoo'],
    pdf: '#', ext: 'https://support.microsoft.com/en-us/powerpoint',
    modules_list: [
      {id:'mp-1',title:'Interface & Slide Layouts',duration:'20 min'},
      {id:'mp-2',title:'Adding Text, Images & Icons',duration:'25 min'},
      {id:'mp-3',title:'Themes, Colours & Design Principles',duration:'30 min'},
      {id:'mp-4',title:'Transitions & Animations',duration:'25 min'},
      {id:'mp-5',title:'Charts, Tables & SmartArt',duration:'30 min'},
      {id:'mp-6',title:'Speaker Notes & Presenting',duration:'20 min'},
    ],
    quiz: [
      {q:'What is the standard slide ratio in modern PowerPoint?',opts:['4:3','16:9','3:2','1:1'],ans:1},
      {q:'Speaker Notes are visible to:',opts:['The audience','The presenter only','Everyone','Nobody'],ans:1},
      {q:'Which feature moves between slides automatically?',opts:['Animation','Theme','Transition','Slide Master'],ans:2},
      {q:'What is a Slide Master?',opts:['The first slide','A template controlling all slide designs','A password protection','A file format'],ans:1},
      {q:'Best practice for slides: aim for how many words per slide?',opts:['As many as possible','50-100 words','Under 30 words','Exactly 10 words'],ans:2},
    ]
  },
  'internet-basics': {
    id: 'internet-basics', title: 'Internet & Digital Literacy', emoji: '🌐',
    category: 'computer', level: 'Beginner', duration: '6 hrs',
    modules: 5, color: 'linear-gradient(135deg,#5B2C6F,#9B59B6)',
    desc: 'Email, internet safety, cloud storage, Google Workspace, and staying safe online.',
    videos: ['https://www.youtube.com/embed/Dxcc6ycZ73M'],
    pdf: '#', ext: 'https://edu.gcfglobal.org/en/internetbasics/',
    modules_list: [
      {id:'ib-1',title:'How the Internet Works',duration:'20 min'},
      {id:'ib-2',title:'Email: Gmail & Professional Communication',duration:'25 min'},
      {id:'ib-3',title:'Google Docs, Sheets & Drive',duration:'30 min'},
      {id:'ib-4',title:'Online Safety & Cybersecurity Basics',duration:'25 min'},
      {id:'ib-5',title:'Social Media, Privacy & Digital Footprint',duration:'20 min'},
    ],
    quiz: [
      {q:'What does "HTTPS" mean in a web address?',opts:['Hyper Text Transfer Protocol Secure','High Tech Transfer Protocol','Home To Transfer Protocol Safely','Hosting Transfer Protocol System'],ans:0},
      {q:'Which is the safest type of password?',opts:['Your birthdate','Your name','A random mix of letters, numbers & symbols','Your phone number'],ans:2},
      {q:'What is "phishing"?',opts:['A fishing game online','A scam to steal your information','A type of web browser','A cloud storage service'],ans:1},
      {q:'What does "CC" mean in an email?',opts:['Carbon Copy','Computer Code','Create Copy','Confidential Communication'],ans:0},
      {q:'Google Drive is a type of:',opts:['Web browser','Search engine','Cloud storage','Email client'],ans:2},
    ]
  },
  'ai-intro': {
    id: 'ai-intro', title: 'Introduction to Artificial Intelligence', emoji: '🤖',
    category: 'ai', level: 'Beginner', duration: '20 hrs',
    modules: 10, color: 'linear-gradient(135deg,#0D1B2A,#1B4F72)',
    desc: 'What is AI? Machine learning, neural networks, and real-world AI applications in Africa.',
    videos: ['https://www.youtube.com/embed/JMUxmLyrhSk','https://www.youtube.com/embed/mJeNghZXtMo'],
    pdf: '#', ext: 'https://www.elementsofai.com/',
    modules_list: [
      {id:'ai-1',title:'What is Artificial Intelligence?',duration:'25 min'},
      {id:'ai-2',title:'History of AI: From 1950s to Today',duration:'20 min'},
      {id:'ai-3',title:'Types of AI: Narrow, General, Super',duration:'20 min'},
      {id:'ai-4',title:'How Machines Learn: Training Data',duration:'30 min'},
      {id:'ai-5',title:'Neural Networks Explained Simply',duration:'30 min'},
      {id:'ai-6',title:'Natural Language Processing (NLP)',duration:'25 min'},
      {id:'ai-7',title:'Computer Vision & Image Recognition',duration:'25 min'},
      {id:'ai-8',title:'AI in Africa: Agriculture, Health, Finance',duration:'30 min'},
      {id:'ai-9',title:'Ethics, Bias & Responsible AI',duration:'25 min'},
      {id:'ai-10',title:'Careers in AI & What\'s Next',duration:'20 min'},
    ],
    quiz: [
      {q:'What does "AI" stand for?',opts:['Automated Intelligence','Artificial Intelligence','Advanced Internet','Automated Integration'],ans:1},
      {q:'Machine Learning is:',opts:['Programming a computer step-by-step','Teaching computers to learn from data','A type of robot','A programming language'],ans:1},
      {q:'Which of these is an example of AI you use daily?',opts:['A calculator','A light switch','Voice assistants like Siri/Google','A pencil'],ans:2},
      {q:'What is a neural network inspired by?',opts:['Computer circuits','The human brain','Tree structures','The internet'],ans:1},
      {q:'Which African challenge can AI help solve?',opts:['Counting stars','Predicting crop diseases','Making cars faster','Nothing relevant to Africa'],ans:1},
    ]
  },
  'ml-basics': {
    id: 'ml-basics', title: 'Machine Learning Fundamentals', emoji: '🧠',
    category: 'ai', level: 'Intermediate', duration: '25 hrs',
    modules: 12, color: 'linear-gradient(135deg,#1A1A2E,#E94560)',
    desc: 'Supervised & unsupervised learning, decision trees, regression, build your first ML model.',
    videos: ['https://www.youtube.com/embed/Gv9_4yMHFhI','https://www.youtube.com/embed/aircAruvnKk'],
    pdf: '#', ext: 'https://www.kaggle.com/learn/intro-to-machine-learning',
    modules_list: [
      {id:'ml-1',title:'What is Machine Learning?',duration:'25 min'},
      {id:'ml-2',title:'Supervised vs Unsupervised Learning',duration:'30 min'},
      {id:'ml-3',title:'Linear Regression',duration:'35 min'},
      {id:'ml-4',title:'Logistic Regression & Classification',duration:'35 min'},
      {id:'ml-5',title:'Decision Trees & Random Forests',duration:'40 min'},
      {id:'ml-6',title:'K-Nearest Neighbours (KNN)',duration:'30 min'},
      {id:'ml-7',title:'Overfitting, Underfitting & Validation',duration:'30 min'},
      {id:'ml-8',title:'Feature Engineering',duration:'35 min'},
      {id:'ml-9',title:'Clustering: K-Means',duration:'30 min'},
      {id:'ml-10',title:'Introduction to Deep Learning',duration:'40 min'},
      {id:'ml-11',title:'Using Scikit-Learn in Python',duration:'50 min'},
      {id:'ml-12',title:'Project: Crop Yield Predictor (Kenya)',duration:'90 min'},
    ],
    quiz: [
      {q:'In supervised learning, the training data:',opts:['Has no labels','Has labels (correct answers)','Is always images','Comes from the internet only'],ans:1},
      {q:'What does "overfitting" mean?',opts:['Model is too simple','Model memorises training data and fails on new data','Model trains too fast','Model uses too much electricity'],ans:1},
      {q:'Which algorithm splits data into groups by similarity?',opts:['Linear Regression','Decision Tree','K-Means Clustering','Logistic Regression'],ans:2},
      {q:'What is a "training set"?',opts:['A gym schedule','Data used to teach the model','Test questions for students','A type of algorithm'],ans:1},
      {q:'Scikit-learn is a Python library for:',opts:['Web development','Game development','Machine learning','Database management'],ans:2},
    ]
  },
  'iot-basics': {
    id: 'iot-basics', title: 'Internet of Things (IoT)', emoji: '📡',
    category: 'ai', level: 'Beginner', duration: '18 hrs',
    modules: 9, color: 'linear-gradient(135deg,#0B3D0B,#27AE60)',
    desc: 'Smart devices, sensors, Arduino, Raspberry Pi. Build smart agriculture and home projects.',
    videos: ['https://www.youtube.com/embed/LlhmzVL5bm8','https://www.youtube.com/embed/h0gWfVCSGQQ'],
    pdf: '#', ext: 'https://www.cisco.com/c/en/us/solutions/internet-of-things/overview.html',
    modules_list: [
      {id:'iot-1',title:'What is IoT? Connected World Overview',duration:'25 min'},
      {id:'iot-2',title:'Sensors, Actuators & Microcontrollers',duration:'30 min'},
      {id:'iot-3',title:'Introduction to Arduino',duration:'40 min'},
      {id:'iot-4',title:'Introduction to Raspberry Pi',duration:'40 min'},
      {id:'iot-5',title:'Networking: WiFi, Bluetooth, LoRa',duration:'30 min'},
      {id:'iot-6',title:'Cloud Platforms for IoT: AWS, Azure',duration:'35 min'},
      {id:'iot-7',title:'IoT for Smart Agriculture in Kenya',duration:'35 min'},
      {id:'iot-8',title:'IoT for Smart Homes & Cities',duration:'30 min'},
      {id:'iot-9',title:'Project: Soil Moisture Monitoring System',duration:'90 min'},
    ],
    quiz: [
      {q:'IoT stands for:',opts:['Internet of Technology','Internet of Things','Integration of Technology','Interface of Tools'],ans:1},
      {q:'An Arduino is:',opts:['A type of phone','A microcontroller board for prototyping','A cloud platform','A programming language'],ans:1},
      {q:'Which sensor measures temperature?',opts:['Ultrasonic sensor','PIR sensor','DHT11 sensor','Light sensor'],ans:2},
      {q:'LoRa is used for:',opts:['Fast internet','Long-range, low-power wireless communication','High-resolution cameras','Video streaming'],ans:1},
      {q:'Which IoT application is relevant to Kenyan farmers?',opts:['Smart traffic lights','Soil moisture monitoring','Autonomous cars','Smart elevators'],ans:1},
    ]
  },
  'ai-tools': {
    id: 'ai-tools', title: 'AI Tools for Work & Life', emoji: '🛠️',
    category: 'ai', level: 'Beginner', duration: '10 hrs',
    modules: 7, color: 'linear-gradient(135deg,#2C1654,#7D3C98)',
    desc: 'ChatGPT, Gemini, Midjourney, Canva AI — use AI to be 10× more productive.',
    videos: ['https://www.youtube.com/embed/JTxsNm9IdYU'],
    pdf: '#', ext: 'https://openai.com/chatgpt',
    modules_list: [
      {id:'at-1',title:'Introduction to Generative AI',duration:'20 min'},
      {id:'at-2',title:'Mastering ChatGPT & Gemini',duration:'35 min'},
      {id:'at-3',title:'AI for Writing & Communication',duration:'30 min'},
      {id:'at-4',title:'AI for Images: Midjourney & DALL-E',duration:'25 min'},
      {id:'at-5',title:'Canva AI & Design Tools',duration:'25 min'},
      {id:'at-6',title:'AI for Research & Learning',duration:'25 min'},
      {id:'at-7',title:'Building a Personal AI Workflow',duration:'30 min'},
    ],
    quiz: [
      {q:'ChatGPT is developed by:',opts:['Google','Microsoft','OpenAI','Amazon'],ans:2},
      {q:'What is "prompt engineering"?',opts:['Building a prompt app','Crafting inputs to get better AI outputs','Engineering a new type of computer','Designing physical prompt buttons'],ans:1},
      {q:'Generative AI can:',opts:['Only answer questions','Only make images','Create text, images, code, audio and more','Physically build things'],ans:2},
      {q:'Google Gemini is:',opts:['A search engine','A social media platform','Google\'s AI assistant','A Google phone'],ans:2},
      {q:'What should you NEVER share with an AI chatbot?',opts:['Your essay topic','Passwords or private data','A creative writing prompt','A recipe you like'],ans:1},
    ]
  },
  'python-basics': {
    id: 'python-basics', title: 'Python Programming', emoji: '🐍',
    category: 'coding', level: 'Beginner', duration: '30 hrs',
    modules: 15, color: 'linear-gradient(135deg,#1C3144,#3498DB)',
    desc: 'Start from zero. Variables, loops, functions, and building real projects in the world\'s most popular language.',
    videos: ['https://www.youtube.com/embed/rfscVS0vtbw','https://www.youtube.com/embed/8DvywoWv6fI'],
    pdf: '#', ext: 'https://docs.python.org/3/tutorial/',
    modules_list: [
      {id:'py-1',title:'Why Python? Setup & First Program',duration:'25 min'},
      {id:'py-2',title:'Variables & Data Types',duration:'30 min'},
      {id:'py-3',title:'String Operations',duration:'25 min'},
      {id:'py-4',title:'Numbers, Math & Type Conversion',duration:'25 min'},
      {id:'py-5',title:'Getting User Input',duration:'20 min'},
      {id:'py-6',title:'Conditionals: if, elif, else',duration:'30 min'},
      {id:'py-7',title:'Loops: for & while',duration:'35 min'},
      {id:'py-8',title:'Lists & Tuples',duration:'30 min'},
      {id:'py-9',title:'Dictionaries',duration:'30 min'},
      {id:'py-10',title:'Functions & Reusability',duration:'35 min'},
      {id:'py-11',title:'File Handling: Read & Write',duration:'30 min'},
      {id:'py-12',title:'Error Handling: try / except',duration:'25 min'},
      {id:'py-13',title:'Modules & Libraries (os, math, random)',duration:'30 min'},
      {id:'py-14',title:'Project: Student Grade Calculator',duration:'60 min'},
      {id:'py-15',title:'Project: M-Pesa Fee Calculator',duration:'75 min'},
    ],
    quiz: [
      {q:'What keyword defines a function in Python?',opts:['function','func','def','create'],ans:2},
      {q:'What will print(type(3.14)) output?',opts:["<class 'int'>","<class 'str'>","<class 'float'>","<class 'number'>"],ans:2},
      {q:'What does len("Kenya") return?',opts:['5','6','4','Kenya'],ans:0},
      {q:'What is the output of: 10 % 3',opts:['3','1','3.33','0'],ans:1},
      {q:'Which loop is best when you know the number of iterations?',opts:['while loop','for loop','do-while loop','repeat loop'],ans:1},
    ]
  },
  'web-basics': {
    id: 'web-basics', title: 'Web Development Basics', emoji: '🌐',
    category: 'coding', level: 'Beginner', duration: '24 hrs',
    modules: 12, color: 'linear-gradient(135deg,#7B3F00,#E67E22)',
    desc: 'HTML, CSS, and JavaScript. Build your first website from scratch — no experience needed.',
    videos: ['https://www.youtube.com/embed/mU6anWqZJcc','https://www.youtube.com/embed/cyuzt9MIskY'],
    pdf: '#', ext: 'https://developer.mozilla.org/en-US/docs/Learn',
    modules_list: [
      {id:'wb-1',title:'How the Web Works',duration:'20 min'},
      {id:'wb-2',title:'HTML: Structure & Semantic Tags',duration:'35 min'},
      {id:'wb-3',title:'HTML: Forms, Tables & Links',duration:'30 min'},
      {id:'wb-4',title:'CSS: Selectors, Properties & Values',duration:'35 min'},
      {id:'wb-5',title:'CSS: Box Model & Layout',duration:'35 min'},
      {id:'wb-6',title:'CSS: Flexbox & Grid',duration:'40 min'},
      {id:'wb-7',title:'CSS: Responsive Design & Media Queries',duration:'35 min'},
      {id:'wb-8',title:'JavaScript: Variables, Functions & Events',duration:'40 min'},
      {id:'wb-9',title:'JavaScript: DOM Manipulation',duration:'40 min'},
      {id:'wb-10',title:'JavaScript: Fetch API & JSON',duration:'35 min'},
      {id:'wb-11',title:'Project: Personal Portfolio Website',duration:'90 min'},
      {id:'wb-12',title:'Deploying to Netlify (Free)',duration:'30 min'},
    ],
    quiz: [
      {q:'HTML stands for:',opts:['Hyper Text Markup Language','Hyper Tool Make Language','High Text Making Links','Hyper Transfer Markup Listings'],ans:0},
      {q:'Which HTML tag creates a heading level 1?',opts:['<heading>','<h1>','<title>','<header>'],ans:1},
      {q:'In CSS, what does "margin" control?',opts:['Space inside the element','Space outside the element','The element colour','The element font'],ans:1},
      {q:'What does JavaScript primarily do on websites?',opts:['Define structure','Style visuals','Add interactivity and behaviour','Store data'],ans:2},
      {q:'Which company created Netlify?',opts:['Google','Amazon','Netlify Inc.','Microsoft'],ans:2},
    ]
  },
  'linux-basics': {
    id: 'linux-basics', title: 'Linux Fundamentals', emoji: '🐧',
    category: 'coding', level: 'Beginner', duration: '16 hrs',
    modules: 10, color: 'linear-gradient(135deg,#1B1B1B,#555555)',
    desc: 'Command line, file system, shell scripting. Linux powers the internet — learn to command it.',
    videos: ['https://www.youtube.com/embed/ROjZy1WbCIA','https://www.youtube.com/embed/rrB13utjYV4'],
    pdf: '#', ext: 'https://training.linuxfoundation.org',
    modules_list: [
      {id:'lx-1',title:'What is Linux? History & Distributions',duration:'20 min'},
      {id:'lx-2',title:'The Terminal: Your Power Tool',duration:'30 min'},
      {id:'lx-3',title:'File System: Navigation (ls, cd, pwd)',duration:'25 min'},
      {id:'lx-4',title:'Files & Directories (mkdir, rm, cp, mv)',duration:'30 min'},
      {id:'lx-5',title:'Viewing & Editing Files (cat, nano, vim)',duration:'30 min'},
      {id:'lx-6',title:'Permissions & Users (chmod, chown)',duration:'30 min'},
      {id:'lx-7',title:'Package Management (apt, yum)',duration:'25 min'},
      {id:'lx-8',title:'Processes & Jobs (ps, kill, top)',duration:'25 min'},
      {id:'lx-9',title:'Shell Scripting Basics',duration:'40 min'},
      {id:'lx-10',title:'Networking Commands (ping, ssh, curl)',duration:'30 min'},
    ],
    quiz: [
      {q:'What command shows the current directory in Linux?',opts:['cd','ls','pwd','dir'],ans:2},
      {q:'What does "chmod 755 file.sh" do?',opts:['Deletes the file','Gives owner full permissions, others read+execute','Renames the file','Moves the file'],ans:1},
      {q:'Which command installs software on Ubuntu/Debian?',opts:['yum install','apt install','brew install','pip install'],ans:1},
      {q:'What does "sudo" mean?',opts:['Super user do (run as administrator)','Search user directory','System update do','Start Unix daemon operation'],ans:0},
      {q:'Linux powers approximately what % of the world\'s web servers?',opts:['30%','50%','70%','96%'],ans:3},
    ]
  },
  'databases': {
    id: 'databases', title: 'Databases & SQL', emoji: '🗄️',
    category: 'coding', level: 'Intermediate', duration: '14 hrs',
    modules: 8, color: 'linear-gradient(135deg,#0F3460,#533483)',
    desc: 'Store and query data. SQL is the language every developer needs. Build databases from scratch.',
    videos: ['https://www.youtube.com/embed/HXV3zeQKqGY','https://www.youtube.com/embed/qw--VYLpxG4'],
    pdf: '#', ext: 'https://www.w3schools.com/sql/',
    modules_list: [
      {id:'db-1',title:'What is a Database? SQL vs NoSQL',duration:'25 min'},
      {id:'db-2',title:'Tables, Rows, Columns & Keys',duration:'25 min'},
      {id:'db-3',title:'SELECT: Querying Data',duration:'30 min'},
      {id:'db-4',title:'WHERE, AND, OR, NOT Conditions',duration:'30 min'},
      {id:'db-5',title:'INSERT, UPDATE, DELETE',duration:'30 min'},
      {id:'db-6',title:'JOINs: Combining Tables',duration:'40 min'},
      {id:'db-7',title:'Aggregation: COUNT, SUM, GROUP BY',duration:'35 min'},
      {id:'db-8',title:'Project: Student Records Database',duration:'60 min'},
    ],
    quiz: [
      {q:'SQL stands for:',opts:['Structured Query Language','Simple Query Language','System Query Links','Standard Quick Language'],ans:0},
      {q:'Which SQL command retrieves data?',opts:['GET','FIND','SELECT','FETCH'],ans:2},
      {q:'Which clause filters rows in SQL?',opts:['GROUP BY','ORDER BY','WHERE','HAVING'],ans:2},
      {q:'A PRIMARY KEY must be:',opts:['The first column','Unique and not NULL','A number only','Shared between tables'],ans:1},
      {q:'What does JOIN do in SQL?',opts:['Merges two databases','Combines rows from multiple tables','Joins two servers','Duplicates data'],ans:1},
    ]
  }
};

// ──────────────────────────────────────────────
// INIT ON DOM READY
// ──────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  initNavbar();
  animateCounters();
  initReveal();
  initTabs();
  initSmoothScroll();
});
